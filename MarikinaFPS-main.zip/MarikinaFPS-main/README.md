# Marikina FPS

A touch-friendly 3D city shooter built with Rust and Macroquad. The playable arena uses the supplied Marikina city GLB map, converted to a compact triangle cache for the game's batched renderer. The supplied GLB was converted into the runtime cache at `assets/dockyard/marikina-city.meshbin`. The original GLB is omitted from this GitHub-upload ZIP to keep the archive below the browser upload limit; the converted map geometry used by the game is included.

## Run it

```sh
cargo run --release
```

## Controls

- **Desktop:** WASD move, Shift sprint, hold right mouse to look, left mouse fire, V switch rifle/knife, Space jump, R reload, F aim, Q/E or mouse wheel adjust magnification, C sneak/slide, Ctrl sneak, Esc quit.
- **Touch:** floating joystick on the left, drag the right side to look. Fire, Jump, Rel, Scope and Snk/Slide are on-screen controls. Use the weapon button at the bottom to switch rifle/knife.
- Push the stick fully forward or hold Shift to run. The Snk button becomes Slide while sprinting.
- Settings > Customize HUD lets you drag and scale touch controls.

## Android APK / ZIP-based repository workflow

The GitHub Actions workflow is `.github/workflows/android-apk.yml`. If a source `.zip` is present in the repository, the workflow extracts it and builds from the first `Cargo.toml` found inside. Otherwise it builds the checked-out project directly. The APK is uploaded as the `marikina-fps-android-apk` workflow artifact.

## Map notes

The GLB contains a single neutral-gray mesh without texture images or vertex colors. Its geometry is scaled and centered to fit the 52 × 52 m arena. The game currently uses perimeter collision bounds; the GLB does not contain authored collision data. Distant chunks use triangle-sampled LOD to reduce rendering work.

## License

The game source is MIT licensed. The original dockyard asset attribution remains in `assets/dockyard/ATTRIBUTION.txt`. The newly supplied Marikina GLB was provided by the project owner and converted into the included runtime mesh cache; retain its original license/attribution if redistributing the source asset.
